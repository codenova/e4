using e4Exercise;
using e4Exercise.Controllers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NUnit.Framework;
using System.Collections.Generic;

namespace NUnitTestStudent
{
    public class Tests
    {
        

        private  IConfiguration _configuration;
        private  ILogger<StudentController> _logger;

        [SetUp]
        public void Startup()
        {

        }

        public void Startup(ILogger<StudentController> logger, IConfiguration configuration )
        {
            _logger = logger;
            _configuration = configuration;
        }

       

        [Test]
        public void studentcount()
        {
            //Please umcoment code to test

            //StudentController studentController = new StudentController();

            //var result = studentController.Get() as List<Student>;
            ////Just use "4" 
            //Assert.AreEqual(4, result.Count);

        }
    }
}