﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace e4Exercise.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StudentController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        
        private readonly ILogger<StudentController> _logger;

        //this is the default contruct from Unit testing/ Please uncomment it if you run UnitTest
       // public StudentController(){}

        public StudentController(ILogger<StudentController> logger , IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        [HttpGet]
        public IEnumerable<Student> Get()
        {
            List<Student> students = GetStudents();
          
            return students;
        }


        [HttpPost]
        public void post([FromBody] Student student)
        {
            SaveStudent(student);
        }


        [HttpDelete]
        public void Delete([FromBody] Student student)
        {
            DeleteStudent(student.StudentID);
        }

        private List<Student> GetStudents()
        {
            //Please hard code connectionString values if you run unit test, _configuration is not injected on TestSetup
            string connectionString = _configuration.GetSection("DbSettings").GetSection("DbConnection").Value;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetStudents", connection))
                {
                    List<Student> Students = new List<Student>();
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    using (SqlDataReader dataReader = command.ExecuteReader())
                    {
                        while (dataReader.Read())
                        {
                            Students.Add(new Student
                            {
                                Name = dataReader["Name"].ToString(),
                                Surname = dataReader["Surname"].ToString(),
                                Grade = dataReader["Grade"].ToString(),
                                IsActive = Convert.ToBoolean(dataReader["IsActive"])
                            });
                        }
                    }
                    connection.Close();
                    return Students;
                }
            }
        }

        private void SaveStudent(Student student)
        {
            string connectionString = _configuration.GetSection("DbSettings").GetSection("DbConnection").Value;

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("SaveStudent", connection);
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.AddWithValue("@Name", student.Name);
                command.Parameters.AddWithValue("@Surname", student.Surname);
                command.Parameters.AddWithValue("@Grade", student.Grade);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

        }

        private void DeleteStudent(int studentID)
        {
            string connectionString = _configuration.GetSection("DbSettings").GetSection("DbConnection").Value;

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("DeleteStudent", connection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@StudentID", studentID);
               
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
