using System;

namespace e4Exercise
{
    public class Student
    {
        public int StudentID { get; set; }
        public string Name { get; set; }

        public string Surname { get; set; }

        public string Grade { get; set; }

        public bool IsActive { get; set; }
    }
}
